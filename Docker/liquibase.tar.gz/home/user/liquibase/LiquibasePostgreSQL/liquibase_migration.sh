###################################################################
#Script Name	: Liquibase_migration.sh                                                                                             
#Description	: DB_VERSIONNING                                                                           
#Args         : Action (MIGRATION), Project_tag(v1.0)                                                                                         
#Author       : Ahmed Abdeljelil (FDKB9702)                                                
#Email        : ahmed.abdeljelil@sofrecom.com                                          
###################################################################
################Include_Init_file############################
. ./Config/init.sh

################GET TAG and Action Variables############################
SCRIPT=`readlink -f "$0"`
P_PATH_MIGRATION=`dirname "$SCRIPT"`


P_ACTION=${1}
P_TAG_MIGRATION=${2}

tag1=$(formattage_version "$P_TAG_MIGRATION")
P_ACTION=$(echo "$P_ACTION" | awk '{print toupper($0)}')

if [ $P_ACTION = "HELP"  ]; then
Help "help"  
exit
fi

echo "------------------------------------ Check_Action_Parameter: ${P_ACTION} ------------------------------------------" 


if [ "$P_ACTION" != "MIGRATION" ] && [ "$P_ACTION" != "HELP" ] 
then
  echo "ERROR: Unkown_Action $P_ACTION. Please_Enter_Valid_Action"
  echo "End_${P_ACTION}_Action_${P_CODE}" 
  echo "--------------------------------------------------------------------------------------------------------"  
  exit 1
fi


echo "------------------------------------ End_Check_Action_Parameter: ${P_ACTION} --------------------------------------" 
  echo "------------------------------------ Check_Tag_Parameter: $P_TAG_MIGRATION ------------------------------------------"    
  if [[ $P_TAG_MIGRATION == "v"* ]]; then
  echo "Valid_Tag_Parameter: $P_TAG_MIGRATION"
  echo "------------------------------------ End_Check_Tag_Parameter: $P_TAG_MIGRATION ------------------------------------------"
  else 
  echo "ERROR: Wrong_Tag_Format. Please_Enter_Valid_Tag"
  echo "End_${P_ACTION}_Action_${P_CODE}" 
  echo "--------------------------------------------------------------------------------------------------------"   
  exit 1
  fi



echo "----------------------------------Starting $P_ACTION Action----------------------------------------" 
echo "------------------------------------ Required_Directories------------------------------------------"
P_PATH_T="$(echo $P_PATH_MIGRATION/$P_PROJECTNAME_MIGRATION/$P_TAG_MIGRATION/)"
P_PATH_CONFIG="$(echo $P_PATH_MIGRATION/Config/)"
P_PATH_LOG="$(echo $P_PATH_MIGRATION/Logs/)"
P_PATH_HISTORY="$(echo $P_PATH_MIGRATION/History/)"
P_PATH_DIFF="$(echo $P_PATH_MIGRATION/Diff/)"
P_PATH_DOC="$(echo $P_PATH_MIGRATION/Doc/)"
P_PATH_CHANGELOG="$(echo $P_PATH_MIGRATION/Changelogs/)"
P_LOG_FILE="$(echo $P_PATH_LOG$P_LOGFILENAME_MIGRATION)"
P_DIFF_FILE="$(echo $P_PATH_DIFF$P_DIFFFILENAME_MIGRATION)"
P_HISTORY_FILE="$(echo $P_PATH_HISTORY$P_HISTORYFILENAME_MIGRATION)"
P_DOC_FILE="$(echo $P_PATH_DOC$P_DOCFILENAME_MIGRATION)"
P_CHANGELOG_FILE="$(echo $P_PATH_CHANGELOG$P_CHANGELOGFILENAME_MIGRATION)"

echo "$P_ACTION Directory:$P_PATH_T"
echo "Config Directory:$P_PATH_CONFIG"
echo "Log Directory:$P_PATH_LOG"
echo "History Directory:$P_PATH_HISTORY"
echo "Diff Directory:$P_PATH_DIFF"
echo "Doc Directory:$P_PATH_DOC"
echo "Changelog Directory:$P_PATH_CHANGELOG"

echo "-------------------------- Check_DB_connexion -------------------------------"

DB_CONNEXION=`psql -q -t -A -h $P_HOSTNAME_MIGRATION -p $P_PORT_MIGRATION -d $P_DBNAME_MIGRATION -U $P_USER_MIGRATION -c "SELECT 1;"`
if [ $DB_CONNEXION == "1" ] 
then 
echo "DB_Connexion_OK"; 
else 
echo "DB_Connexion_NOK";
echo "End_${P_ACTION}_Action_${P_CODE}" 
echo "--------------------------------------------------------------------------------------------------------"   
exit 1;
fi
echo "------------------------- End_Check_DB_connexion -----------------------------"


echo "------------------Check_Directories_AND_Config_Files_Existance------------------" 
if [ ! -d $P_PATH_T ] 
then 
    echo "Treatement Directory $P_PATH_T DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"
    exit 1 
elif [ ! -d $P_PATH_CONFIG ] 
then
    echo "Config Directory $P_PATH_CONFIG DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"
    exit 1 
elif [ ! -d $P_PATH_LOG ] 
then
    echo "Log Directory $P_PATH_CONFIG DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"    
    exit 1 
elif [ ! -d $P_PATH_HISTORY ] 
then
    echo "Log Directory $P_PATH_HISTORY DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"    
    exit 1   
elif [ ! -d $P_PATH_DIFF ] 
then
    echo "Log Directory $P_PATH_HISTORY DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"    
    exit 1          
else    

if [ -z "$(ls -A $P_PATH_CONFIG)" ]; then
    echo "Config File DOES NOT exists"
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"   
    exit 1   
fi

if [ -z "$(ls -A $P_PATH_T)" ]; then
   echo "Treatement Folder Is Empty"
   P_CODE="NOK"
   echo "End $P_ACTION Action $P_CODE"   
   exit 1   
   echo "Environment Ready To Start $P_ACTION Action"
   echo "$P_ACTION Action Starting"   
   echo "-------------------------------Files_list_for_processing-------------------------------------------"

   echo "-------------------------------------Migration_Scripts-----------------------------------------------"
   if [ ! -d "$P_PATH_T/DB_Migration" ] 
   then 
     echo "Migration Directory $P_PATH_T/DB_Migration DOES NOT exists." 
     P_CODE="NOK"
     echo "End $P_ACTION Action $P_CODE"     
     exit 1 
   else 
   cd "$P_PATH_T/DB_Migration"
     if [ -z "$(ls -A $P_PATH_T/DB_Migration)" ]; then
     echo "Migration Directory Is Empty "
     P_CODE="NOK"
     echo "End $P_ACTION Action $P_CODE"     
     exit 1 
     else 
     ls -l *.sql| awk '{print $9}'       
     fi      
   fi 
   
   echo "------------------------------------------Init_Files-----------------------------------------------"   
   if [ ! -d "$P_PATH_T/Init" ] 
   then 
     echo "Init Directory $P_PATH_T/Init DOES NOT exists." 
     P_CODE="NOK"
     echo "End $P_ACTION Action $P_CODE"
     exit 1 
   else 
   cd "$P_PATH_T/Init"
     if [ -z "$(ls -A $P_PATH_T/Init)" ]; then
     echo "WARNING:Init Directory Is Empty "   
     else 
     ls -l *.sql| awk '{print $9}'       
     fi      
   fi 
fi


for file in $P_PATH_T*/*.sql
do 
count=`psql -q -t -A -h $P_HOSTNAME_MIGRATION -p $P_PORT_MIGRATION -d $P_DBNAME_MIGRATION -U $P_USER_MIGRATION -c "SELECT count (*) FROM information_schema.tables WHERE table_schema='public' and table_name='databasechangelog';"`

if [ $count = "0" ]
then
    id="1";
else
id=`psql -q -t -A -h $P_HOSTNAME_MIGRATION -p $P_PORT_MIGRATION -d $P_DBNAME_MIGRATION -U $P_USER_MIGRATION -c "select max(CAST (id AS INTEGER))+1 from databasechangelog;"`  
fi
oldchangeset=`grep changeset $file | cut -d" " -f2`
author="$(echo $oldchangeset | awk -F':' '{print $1}')"
newchangeset="$(echo $author:$id)"
sed -i -e "s/$oldchangeset/$newchangeset/g" $file
filename="$(echo $file | rev | cut -d/ -f1 | rev)"
echo "-----------------------Start Processing File: $filename------------------------------------"

#cd $P_PATH_CONFIG
#liquibase --changeLogFile="$file" --logFile="$P_LOG_FILE" update
liquibase --driver="$P_DRIVER_MIGRATION" --classpath="$P_CLASSPATH_MIGRATION" --defaultSchemaName="$P_DEFAULTSCHEMANAME_MIGRATION" --url="$P_URL_MIGRATION" --username="$P_USER_MIGRATION" --password="$P_PWD_MIGRATION"  --changeLogFile="$file" --logFile="$P_LOG_FILE" update    
if [ ! $? = 0 ]
then
     echo "End $P_ACTION Action $P_CODE"
     exit 1
fi  
#liquibase --changeLogFile="$file" tag $tag
liquibase --driver="$P_DRIVER_MIGRATION" --classpath="$P_CLASSPATH_MIGRATION" --defaultSchemaName="$P_DEFAULTSCHEMANAME_MIGRATION" --url="$P_URL_MIGRATION" --username="$P_USER_MIGRATION" --password="$P_PWD_MIGRATION"  --changeLogFile="$file" tag $tag1
if [ ! $? = 0 ]
then
     echo "Warning : Error While Tag"
fi 
echo "--------------------------End Processing File: $filename-----------------------------------"
done
echo "--------------------------Start_Generation_History_Changes------------------------------------"
#liquibase --outputFile="$P_PATH_HISTORY/$P_HISTORYFILENAME" history
liquibase --url="$P_URL_MIGRATION"   --username="$P_USER_MIGRATION" --password="$P_PWD_MIGRATION" --outputFile="$P_PATH_HISTORY/$P_HISTORYFILENAME_MIGRATION" history
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating History"
fi 
echo "--------------------------End_Generation_History_Changes------------------------------------"

echo "---------------------------Start_Generation_Documentation--------------------------------------------"
#liquibase --changeLogFile="$P_CHANGELOG_FILE" generateChangeLog

liquibase --driver="$P_DRIVER_MIGRATION" --classpath="$P_CLASSPATH_MIGRATION" --defaultSchemaName="$P_DEFAULTSCHEMANAME_MIGRATION" --url="$P_URL_MIGRATION" --username="$P_USER_MIGRATION" --password="$P_PWD_MIGRATION" --changeLogFile="$P_CHANGELOG_FILE" generateChangeLog
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Changelog XML"
fi

liquibase --driver="$P_DRIVER_MIGRATION" --url="$P_URL_MIGRATION" --username="$P_USER_MIGRATION" --password="$P_PWD_MIGRATION" --changeLogFile="$P_CHANGELOG_FILE" dbDoc "$P_DOC_FILE"
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Documentation"
fi
echo "---------------------------END_Generation_Documentation--------------------------------------------"
echo "---------------------------Start_Diff_Generation--------------------------------------------"
liquibase --outputFile="$P_DIFF_FILE" --driver="$P_DRIVER_MIGRATION" --classpath="$P_CLASSPATH_MIGRATION" --url="$P_URL_MIGRATION" --username="$P_USER_MIGRATION" --password="$P_PWD_MIGRATION" diff --referenceUrl="$P_REFERENCEURL_MIGRATION" --referenceUsername="$P_REFERENCEUSER_MIGRATION" --referencePassword="$P_REFERENCEPWD_MIGRATION"
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Diff"
fi
echo "---------------------------End_Diff_Generation--------------------------------------------"
fi

echo "----------------------------------End $P_ACTION Action OK----------------------------------------"



