###################################################################
#Script Name	: Liquibase_upgrade.sh                                                                                             
#Description	: DB_VERSIONNING                                                                           
#Args         : Action (UPGRADE), Project_tag(v3.0)                                                                                         
#Author       : Ahmed Abdeljelil (FDKB9702)                                                
#Email        : ahmed.abdeljelil@sofrecom.com                                          
###################################################################

################Include_Init_file############################
. ./Config/init.sh

################GET TAG and Action Variables############################

P_ACTION=${1}
tag=${2}
tag1=$(formattage_version "$tag")


SCRIPT=`readlink -f "$0"`
P_PATH_UPGRADE=`dirname "$SCRIPT"`
echo "P_PATH_UPGRADE: $P_PATH_UPGRADE"
P_PATH_T="$(echo $P_PATH_UPGRADE/$P_PROJECTNAME_UPGRADE/$tag/)"
if [ ! -d $P_PATH_T ] 
then
 echo "Directory $tag DOES NOT exists." 
 exit 1
else 
echo "------------------------------------ Starting_${P_ACTION}_Action ---------------------------------------" 
echo "------------------------------------ Required_Directories ------------------------------------------"

P_PATH_CONFIG="$(echo $P_PATH_UPGRADE/Config/)"
P_PATH_LOG="$(echo $P_PATH_UPGRADE/Logs/)"
P_PATH_HISTORY="$(echo $P_PATH_UPGRADE/History/)"
P_PATH_DIFF="$(echo $P_PATH_UPGRADE/Diff/)"
P_PATH_DOC="$(echo $P_PATH_UPGRADE/Doc/)"
P_PATH_CHANGELOG="$(echo $P_PATH_UPGRADE/Changelogs/)"
P_LOG_FILE="$(echo $P_PATH_LOG$P_LOGFILENAME_UPGRADE)"
P_DIFF_FILE="$(echo $P_PATH_DIFF$P_DIFFFILENAME_UPGRADE)"
P_HISTORY_FILE="$(echo $P_PATH_HISTORY$P_HISTORYFILENAME_UPGRADE)"
P_DOC_FILE="$(echo $P_PATH_DOC$P_DOCFILENAME_UPGRADE)"
P_CHANGELOG_FILE="$(echo $P_PATH_CHANGELOG$P_CHANGELOGFILENAME_UPGRADE)"

echo "$P_ACTION_Main_Directory:$P_PATH_UPGRADE"
echo "Config_Directory:$P_PATH_CONFIG"
echo "Log_Directory:$P_PATH_LOG"
echo "History_Directory:$P_PATH_HISTORY"
echo "Diff_Directory:$P_PATH_DIFF"
echo "Doc_Directory:$P_PATH_DOC"
echo "Changelog_Directory:$P_PATH_CHANGELOG"

P_ACTION=$(echo "$P_ACTION" | awk '{print toupper($0)}')
echo "------------------------------------ Check_Action_Parameter: ${P_ACTION} ------------------------------------------" 

if [ "$P_ACTION" != "UPGRADE" ] && [ "$P_ACTION" != "HELP" ] 
then
  echo "ERROR: Unkown_Action $P_ACTION. Please_Enter_Valid_Action"
  echo "End_${P_ACTION}_Action_${P_CODE}" 
  echo "--------------------------------------------------------------------------------------------------------"  
  exit 1
else
  if [ $P_ACTION = "HELP"  ]; then
  Help "help" 
  exit 
  fi


  echo "Valid_Action_Parameter: $P_ACTION"
  echo "------------------------------------ End_Check_Action_Parameter: ${P_ACTION} --------------------------------------" 
  echo "------------------------------------ Check_Tag_Parameter: $tag ------------------------------------------"    
  if [[ $tag == "v"* ]]; then
  echo "Valid_Tag_Parameter: $tag"
  echo "------------------------------------ End_Check_Tag_Parameter: $tag ------------------------------------------"
  else 
  echo "ERROR: Wrong_Tag_Format. Please_Enter_Valid_Tag"
  echo "End_${P_ACTION}_Action_${P_CODE}" 
  echo "--------------------------------------------------------------------------------------------------------"   
  exit 1
  fi
fi

echo "-------------------------- Check_DB_connexion -------------------------------"

DB_CONNEXION=`psql -q -t -A -h $P_HOSTNAME_UPGRADE -p $P_PORT_UPGRADE -d $P_DBNAME_UPGRADE -U $P_USER_UPGRADE -c "SELECT 1;"`
if [ $DB_CONNEXION == "1" ] 
then 
echo "DB_Connexion_OK"; 
else 
echo "DB_Connexion_NOK";
echo "End_${P_ACTION}_Action_${P_CODE}" 
echo "--------------------------------------------------------------------------------------------------------"   
exit 1;
fi
echo "------------------------- End_Check_DB_connexion -----------------------------"
echo "------------------Check_Directories_AND_Config_Files_Existance------------------" 

if [ ! -d $P_PATH_CONFIG ] 
then
    echo "ERROR: Config Directory $P_PATH_CONFIG DOES NOT exists." 
    echo "End_${P_ACTION}_Action_${P_CODE}" 
    echo "--------------------------------------------------------------------------------------------------------"    
    exit 1 
elif [ ! -d $P_PATH_LOG ] 
then
    echo "ERROR: Log Directory $P_PATH_CONFIG DOES NOT exists." 
    P_CODE="NOK"
    echo "End_${P_ACTION}_Action_${P_CODE}"    
    echo "--------------------------------------------------------------------------------------------------------"    
    exit 1 
elif [ ! -d $P_PATH_HISTORY ] 
then
    echo "ERROR: Log Directory $P_PATH_HISTORY DOES NOT exists." 
    P_CODE="NOK"
    echo "End_${P_ACTION}_Action_${P_CODE}"   
    echo "--------------------------------------------------------------------------------------------------------"        
    exit 1   
elif [ ! -d $P_PATH_DIFF ] 
then
    echo "ERROR: Log Directory $P_PATH_HISTORY DOES NOT exists." 
    P_CODE="NOK"
    echo "--------------------------------------------------------------------------------------------------------"       
    echo "End_${P_ACTION}_Action_${P_CODE}"     
    exit 1   
elif [ ! -d $P_PATH_DOC ] 
then
    echo "ERROR: Log Directory $P_PATH_HISTORY DOES NOT exists." 
    P_CODE="NOK"
    echo "--------------------------------------------------------------------------------------------------------"       
    echo "End_${P_ACTION}_Action_${P_CODE}"     
    exit 1
elif [ ! -d $P_PATH_CHANGELOG ] 
then
    echo "ERROR: Log Directory $P_PATH_HISTORY DOES NOT exists." 
    P_CODE="NOK"
    echo "--------------------------------------------------------------------------------------------------------"       
    echo "End_${P_ACTION}_Action_${P_CODE}"     
    exit 1    
               
else    
    if [ -z "$(ls -A $P_PATH_CONFIG)" ]; then
      echo "ERROR: Config Files DOES NOT exists"
      P_CODE="NOK"
      echo "End_${P_ACTION}_Action_${P_CODE}"    
      exit 1   
    fi

    count=`psql -q -t -A -h $P_HOSTNAME_UPGRADE -p $P_PORT_UPGRADE -d $P_DBNAME_UPGRADE -U $P_USER_UPGRADE -c "SELECT count (*) FROM information_schema.tables WHERE table_schema='public' and table_name  ='databasechangelog';"`


    if [ $count = "0" ]
    then
      tag_db="NULL"
    else
      tag_db=`psql -q -t -A -h $P_HOSTNAME_UPGRADE -p $P_PORT_UPGRADE -d $P_DBNAME_UPGRADE -U $P_USER_UPGRADE -c "select trim(max(tag)) from databasechangelog;"`         
    fi

    if [ $tag_db != "NULL" ] ;
    then
      db_tag=$tag_db
      db_tag=$(echo $db_tag | awk -F'.' '{print $1$2$3$4$5}')      
      db_tag="${db_tag:1}" 
      db_tag=`echo "$((db_tag))"`
    else 
      db_tag="1"
      db_tag=`echo "$((db_tag))"`
    fi
  
    input_tag=$tag1
    input_tag=$(echo $input_tag | awk -F'.' '{print $1$2$3$4$5}') 
    input_tag="${input_tag:1}"
    input_tag=`echo "$((input_tag))"`

    if [[ "$tag_db" == "$tag1" ]] || [[ "$db_tag" -ge "$input_tag" ]] ; then
      echo "WARNING: Version $tag is already installed"
      echo "----------------------------------End $P_ACTION Action OK----------------------------------------"
      exit 0
    else
	  
      for dir in `ls -d -1 $P_PATH_UPGRADE/$P_PROJECTNAME_UPGRADE/*`
	     do
	     #echo "dir: $dir"
           
        if [ ! -d $dir ] 
        then
          echo "Directory $dir DOES NOT exists." 
          continue
        else 
          version1="$(echo $dir | rev | cut -d/ -f1 | rev)"
          tag_version=$(formattage_version "$version1")
          folder_tag=$tag_version
          folder_tag=$(echo $folder_tag | awk -F'.' '{print $1$2$3$4$5}')      
          folder_tag="${folder_tag:1}"
        fi
        

        if  [[ $folder_tag -gt $input_tag ]] || [[ $folder_tag -le $db_tag ]]
        then
          continue
        else

			if [[ $(ls -A $P_PATH_UPGRADE/$P_PROJECTNAME_UPGRADE/$version1) ]]; then
			for sub_dir in `ls -d -1 $P_PATH_UPGRADE/$P_PROJECTNAME_UPGRADE/$version1/*/`
			do
			echo "-----------------------------------------------------------------------------------------------------"   
			echo "Treatment_Sub_Directories_$version1: $sub_dir" 
			if [ -z "$(ls -A $sub_dir)" ]; then
				echo "WARNING:$sub_dir Folder Is Empty"
				echo "---------------------------------------------------------------------------------------------------"
			else 
				echo "-------------------------------------Files_list_for_processing---------------------------------------"
				ls -l $sub_dir*.sql| awk '{print $9}'    
		
				for file in $sub_dir*.sql 
				do
				id_current_changeset=`psql -q -t -A -h $P_HOSTNAME_UPGRADE -p $P_PORT_UPGRADE -d $P_DBNAME_UPGRADE -U $P_USER_UPGRADE -c "select max(CAST (id AS INTEGER))+1 from databasechangelog;"` 
				if [ $? != 0 ]
				then 
					echo "WARNING: databasechangelog DOES NOT exists"
					id_current_changeset="1"
				fi
		
				oldchangeset=`grep changeset $file | cut -d" " -f2`
				author="$(echo $oldchangeset | awk -F':' '{print $1}')"
				newchangeset="$(echo $author:$id_current_changeset)"
				sed -i -e "s/$oldchangeset/$newchangeset/g" $file
				filename="$(echo $file | rev | cut -d/ -f1 | rev)"
				echo "-----------------------Start Processing File: $filename------------------------------------"
        liquibase --driver="$P_DRIVER_UPGRADE" --classpath="$P_CLASSPATH_UPGRADE" --defaultSchemaName="$P_DEFAULTSCHEMANAME_UPGRADE" --url="$P_URL_UPGRADE" --username="$P_USER_UPGRADE" --password="$P_PWD_UPGRADE"  --changeLogFile="$file" --logFile="$P_LOG_FILE" update      
        
				if [ ! $? = 0 ]
				then
					echo "End_${P_ACTION}_Action_${P_CODE}" 
					exit 1
				fi  
        liquibase --driver="$P_DRIVER_UPGRADE" --classpath="$P_CLASSPATH_UPGRADE" --defaultSchemaName="$P_DEFAULTSCHEMANAME_UPGRADE" --url="$P_URL_UPGRADE" --username="$P_USER_UPGRADE" --password="$P_PWD_UPGRADE"  --changeLogFile="$file" tag $tag_version
        
				if [ ! $? = 0 ]
				then
				echo "Warning : Error While Tag"
				fi 
				echo "--------------------------End Processing File: $filename-----------------------------------"        
				echo "---------------------------------------------------------------------------------------------------"    
				done  
			fi   
			done           
			else
			echo "WARNING: No_Treatment_Sub_Directories_Found_Under_Folder : $version1"
			echo "---------------------------------------------------------------------------------------------------"    
			continue    
			fi 
   fi 
	done  
  fi

echo "--------------------------Start_Generation_History_Changes------------------------------------"
liquibase --url="$P_URL_UPGRADE"   --username="$P_USER_UPGRADE" --password="$P_PWD_UPGRADE" --outputFile="$P_PATH_HISTORY/$P_HISTORYFILENAME_UPGRADE" history
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating History"
fi 
echo "--------------------------End_Generation_History_Changes------------------------------------"

echo "---------------------------Start_Generation_Documentation--------------------------------------------"
liquibase --driver="$P_DRIVER_UPGRADE" --classpath="$P_CLASSPATH_UPGRADE" --defaultSchemaName="$P_DEFAULTSCHEMANAME_UPGRADE" --url="$P_URL_UPGRADE" --username="$P_USER_UPGRADE" --password="$P_PWD_UPGRADE" --changeLogFile="$P_CHANGELOG_FILE" generateChangeLog

if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Changelog XML"
fi

if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Changelog SQL"
fi
liquibase --driver="$P_DRIVER_UPGRADE" --url="$P_URL_UPGRADE" --username="$P_USER_UPGRADE" --password="$P_PWD_UPGRADE" --changeLogFile="$P_CHANGELOG_FILE" dbDoc "$P_DOC_FILE"
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Documentation"
fi
echo "---------------------------END_Generation_Documentation--------------------------------------------"
echo "---------------------------Start_Diff_Generation--------------------------------------------"
liquibase --outputFile="$P_DIFF_FILE" --driver="$P_DRIVER_UPGRADE" --classpath="$P_CLASSPATH_UPGRADE" --url="$P_URL_UPGRADE" --username="$P_USER_UPGRADE" --password="$P_PWD_UPGRADE" diff --referenceUrl="$P_REFERENCEURL_UPGRADE" --referenceUsername="$P_REFERENCEUSER_UPGRADE" --referencePassword="$P_REFERENCEPWD_UPGRADE"
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Diff"
fi
echo "---------------------------End_Diff_Generation--------------------------------------------"
fi
fi
echo "----------------------------------End_${P_ACTION}_Action_OK----------------------------------------"