--liquibase formatted sql
--changeset ahmed:5
--comment: Init_data_table_films
insert into films values ('FDKB9702','DEV',1,current_date,'NA');