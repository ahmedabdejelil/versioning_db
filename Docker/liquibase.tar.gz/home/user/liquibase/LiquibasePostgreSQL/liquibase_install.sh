###################################################################
#Script Name	: Liquibase_install.sh                                                                                             
#Description	: DB_VERSIONNING                                                                           
#Args         : Action (INSTALL), Project_tag(init_db)                                                                                         
#Author       : Ahmed Abdeljelil (FDKB9702)                                                
#Email        : ahmed.abdeljelil@sofrecom.com                                          
###################################################################

################Include_Init_file############################
. ./Config/init.sh

################GET TAG and Action Variables############################
P_ACTION=${1}
P_TAG_INSTALL=${2}

SCRIPT=`readlink -f "$0"`
P_PATH_INSTALL=`dirname "$SCRIPT"`

echo $P_PATH_INSTALL

P_ACTION=$(echo "$P_ACTION" | awk '{print toupper($0)}')

if [ $P_ACTION = "HELP"  ]; then
Help "help"
exit  
fi

echo "------------------------------------ Check_Action_Parameter: ${P_ACTION} ------------------------------------------" 


if [ "$P_ACTION" != "INSTALL" ] && [ "$P_ACTION" != "HELP" ] 
then
  echo "ERROR: Unkown_Action $P_ACTION. Please_Enter_Valid_Action"
  echo "End_${P_ACTION}_Action_${P_CODE}" 
  echo "--------------------------------------------------------------------------------------------------------"  
  exit 1
  
fi
echo "Valid_Action_Parameter: $P_ACTION"

echo "------------------------------------ End_Check_Action_Parameter: ${P_ACTION} --------------------------------------" 

echo "----------------------------------Starting $P_ACTION Action----------------------------------------" 
echo "------------------------------------ Required_Directories------------------------------------------"
P_PATH_T="$(echo $P_PATH_INSTALL/Install/)"
P_PATH_CONFIG="$(echo $P_PATH_INSTALL/Config/)"
P_PATH_LOG="$(echo $P_PATH_INSTALL/Logs/)"
P_PATH_HISTORY="$(echo $P_PATH_INSTALL/History/)"
P_PATH_DIFF="$(echo $P_PATH_INSTALL/Diff/)"
P_PATH_DOC="$(echo $P_PATH_INSTALL/Doc/)"
P_PATH_CHANGELOG="$(echo $P_PATH_INSTALL/Changelogs/)"
P_LOG_FILE="$(echo $P_PATH_LOG$P_LOGFILENAME_INSTALL)"
P_DIFF_FILE="$(echo $P_PATH_DIFF$P_DIFFFILENAME_INSTALL)"
P_HISTORY_FILE="$(echo $P_PATH_HISTORY$P_HISTORYFILENAME_INSTALL)"
P_DOC_FILE="$(echo $P_PATH_DOC$P_DOCFILENAME_INSTALL)"
P_CHANGELOG_FILE="$(echo $P_PATH_CHANGELOG$P_CHANGELOGFILENAME_INSTALL)"

echo "$P_ACTION Directory:$P_PATH_T"
echo "Config Directory:$P_PATH_CONFIG"
echo "Log Directory:$P_PATH_LOG"
echo "History Directory:$P_PATH_HISTORY"
echo "Diff Directory:$P_PATH_DIFF"
echo "Doc Directory:$P_PATH_DOC"
echo "Changelog Directory:$P_PATH_CHANGELOG"

echo "-------------------------- Check_DB_connexion -------------------------------"

DB_CONNEXION=`psql -q -t -A -h $P_HOSTNAME_INSTALL -p $P_PORT_INSTALL -d $P_DBNAME_INSTALL -U $P_USER_INSTALL -c "SELECT 1;"`
if [ $DB_CONNEXION == "1" ] 
then 
echo "DB_Connexion_OK"; 
else 
echo "DB_Connexion_NOK";
echo "End_${P_ACTION}_Action_${P_CODE}" 
echo "--------------------------------------------------------------------------------------------------------"   
exit 1;
fi
echo "------------------------- End_Check_DB_connexion -----------------------------"

echo "------------------Check_Directories_AND_Config_Files_Existance------------------" 
if [ ! -d $P_PATH_T ] 
then 
    echo "Treatement Directory $P_PATH_T DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"
    exit 1 
elif [ ! -d $P_PATH_CONFIG ] 
then
    echo "Config Directory $P_PATH_CONFIG DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"
    exit 1 
elif [ ! -d $P_PATH_LOG ] 
then
    echo "Log Directory $P_PATH_CONFIG DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"    
    exit 1 
elif [ ! -d $P_PATH_HISTORY ] 
then
    echo "Log Directory $P_PATH_HISTORY DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"    
    exit 1   
elif [ ! -d $P_PATH_DIFF ] 
then
    echo "Log Directory $P_PATH_HISTORY DOES NOT exists." 
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"    
    exit 1          
else

if [ -z "$(ls -A $P_PATH_CONFIG)" ]; then
    echo "Config File DOES NOT exists"
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"   
    exit 1   
fi

if [ -z "$(ls -A $P_PATH_T)" ]; then
    echo "Treatement Folder Is Empty"
    P_CODE="NOK"
    echo "End $P_ACTION Action $P_CODE"   
    exit 1   
else
   echo "Environment Ready To Start $P_ACTION Action"
   echo "$P_ACTION Action Starting"   
   echo "-------------------------------Files_list_for_processing-------------------------------------------"

   echo "-------------------------------------Structure_Files-----------------------------------------------"
   if [ ! -d "$P_PATH_T/DB_Structure" ] 
   then 
     echo "Structure Directory $P_PATH_T/DB_Structure DOES NOT exists." 
     P_CODE="NOK"
     echo "End $P_ACTION Action $P_CODE"     
     exit 1 
   else 
   cd "$P_PATH_T/DB_Structure"
     if [ -z "$(ls -A $P_PATH_T/DB_Structure)" ]; then
     echo "Structure Directory Is Empty "
     P_CODE="NOK"
     echo "End $P_ACTION Action $P_CODE"     
     exit 1 
     else 
     ls -l *.sql| awk '{print $9}'       
     fi      
   fi 
   
   echo "------------------------------------------Init_Files-----------------------------------------------"   
   if [ ! -d "$P_PATH_T/Init" ] 
   then 
     echo "Init Directory $P_PATH_T/Init DOES NOT exists." 
     P_CODE="NOK"
     echo "End $P_ACTION Action $P_CODE"
     exit 1 
   else 
   cd "$P_PATH_T/Init"
     if [ -z "$(ls -A $P_PATH_T/Init)" ]; then
     echo "WARNING:Init Directory Is Empty "   
     else 
     ls -l *.sql| awk '{print $9}'       
     fi      
   fi 
fi

for file in $P_PATH_T*/*.sql 
do 
count=`psql -q -t -A -h $P_HOSTNAME_INSTALL -p $P_PORT_INSTALL -d $P_DBNAME_INSTALL -U $P_USER_INSTALL -c "SELECT count (*) FROM information_schema.tables WHERE table_schema='public' and table_name='databasechangelog';"`
  
if [ $count = "0" ]
then
    id="1";
else
id=`psql -q -t -A -h $P_HOSTNAME_INSTALL -p $P_PORT_INSTALL -d $P_DBNAME_INSTALL -U $P_USER_INSTALL -c "select max(CAST (id AS INTEGER))+1 from databasechangelog;"`  
fi
   
oldchangeset=`grep changeset $file | cut -d" " -f2`
author="$(echo $oldchangeset | awk -F':' '{print $1}')"
newchangeset="$(echo $author:$id)"
sed -i -e "s/$oldchangeset/$newchangeset/g" $file
filename="$(echo $file | rev | cut -d/ -f1 | rev)"
echo "-----------------------Start Processing File: $filename------------------------------------"

liquibase --driver="$P_DRIVER_INSTALL" --classpath="$P_CLASSPATH_INSTALL" --defaultSchemaName="$P_DEFAULTSCHEMANAME_INSTALL" --url="$P_URL_INSTALL" --username="$P_USER_INSTALL" --password="$P_PWD_INSTALL"  --changeLogFile="$file" --logFile="$P_LOG_FILE" update  
if [ ! $? = 0 ]
then
     P_CODE="NOK"
     echo "End $P_ACTION Action $P_CODE"
     exit 1
fi 
liquibase --driver="$P_DRIVER_INSTALL" --classpath="$P_CLASSPATH_INSTALL" --defaultSchemaName="$P_DEFAULTSCHEMANAME_INSTALL" --url="$P_URL_INSTALL" --username="$P_USER_INSTALL" --password="$P_PWD_INSTALL"  --changeLogFile="$file" tag $P_TAG_INSTALL
if [ ! $? = 0 ]
then
     echo "Warning : Error While Tag"
fi 
echo "--------------------------End Processing File: $filename-----------------------------------"
done
echo "--------------------------Start_Generation_History_Changes------------------------------------"
liquibase --url="$P_URL_INSTALL"   --username="$P_USER_INSTALL" --password="$P_PWD_INSTALL" --outputFile="$P_PATH_HISTORY/$P_HISTORYFILENAME_INSTALL" history
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating History"
fi 
echo "--------------------------End_Generation_History_Changes------------------------------------"
echo "---------------------------Start_Generation_Documentation--------------------------------------------"
liquibase --driver="$P_DRIVER_INSTALL" --classpath="$P_CLASSPATH_INSTALL" --defaultSchemaName="$P_DEFAULTSCHEMANAME_INSTALL" --url="$P_URL_INSTALL" --username="$P_USER_INSTALL" --password="$P_PWD_INSTALL" --changeLogFile="$P_CHANGELOG_FILE" generateChangeLog
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Changelog XML"
fi

liquibase --driver="$P_Driver_INSTALL" --url="$P_URL_INSTALL" --username="$P_USER_INSTALL" --password="$P_PWD_INSTALL" --changeLogFile="$P_CHANGELOG_FILE" dbDoc "$P_DOC_FILE"
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Documentation"
fi
echo "---------------------------END_Generation_Documentation--------------------------------------------"
echo "---------------------------Start_Diff_Generation--------------------------------------------"
liquibase --outputFile="$P_DIFF_FILE" --driver="$P_Driver_INSTALL" --classpath="$P_CLASSPATH_INSTALL" --url="$P_URL_INSTALL" --username="$P_USER_INSTALL" --password="$P_PWD_INSTALL" diff --referenceUrl="$P_REFERENCEURL_INSTALL" --referenceUsername="$P_REFERENCEUSER_INSTALL" --referencePassword="$P_REFERENCEPWD_INSTALL"
if [ ! $? = 0 ]
then
     echo "Warning : Error While Generating Diff"
fi
echo "---------------------------End_Diff_Generation--------------------------------------------"
fi

echo "----------------------------------End $P_ACTION Action OK----------------------------------------"

